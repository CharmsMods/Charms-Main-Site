# Nio-mod-purple
Hello everyone :D, this is my venge mod feel free to use it.

Subscribe to my helper Northsxde's yt channel --> https://www.youtube.com/@NorthSxdeWTF


HOW TO INSTALL THE MOD

1-Make sure to have the official venge client, if not you can get it at this link --> https://social.venge.io/client

2-Download the mod here --> https://github.com/Gionfra/Nio-mod-purple/archive/refs/heads/main.zip

3-Extract the zip and go in the folder "documents" and then "Venge-Client"

4-Move the "files" folder in "Resource Swapper" folder and the "charfix.js" file in the "Scripts" folder

5-Launch the client and enjoy ;D
