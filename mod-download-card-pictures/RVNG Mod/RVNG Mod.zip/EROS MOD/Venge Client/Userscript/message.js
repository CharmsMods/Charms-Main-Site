const messages = [
  "RVNG ON TOP GG EZ!",
  "RVNG EZ WIN!",
  "RVNG IS THE BEST!",
  "EZ LOL RVNG ON TOP!",
  "SMOKED BY RVNG!",
];

function sendRandomMessage() {
  const randomIndex = Math.floor(Math.random() * messages.length);
  const message = messages[randomIndex];
 
  // Send the message to the message console
  pc.app.fire("Network:Chat", message);
}

function handleKeyPress(event) {
  const key = event.key;
 
  if (key === "#") {
    sendRandomMessage();
  }
}

document.addEventListener("keydown", handleKeyPress);




