const messages = [
  "Will you follow me? GG!",
 
];

function sendRandomMessage() {
  const randomIndex = Math.floor(Math.random() * messages.length);
  const message = messages[randomIndex];
 
  // Send the message to the message console
  pc.app.fire("Network:Chat", message);
}

function handleKeyPress(event) {
  const key = event.key;
 
  if (key === "`") {
    sendRandomMessage();
  }
}

document.addEventListener("keydown", handleKeyPress);




