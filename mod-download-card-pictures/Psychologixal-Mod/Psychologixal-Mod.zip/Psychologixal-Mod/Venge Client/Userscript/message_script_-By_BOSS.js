// idea, code and production by BO$$. and nitesvh. Press the ":" and "/" 
//keys to send a random message in the game, for example after being killed. 
//Make the most of it! You can customize the messages and the key easily.

// Array of random messages
const messages = [
  "Nice shot!",
  "Join SHOT clan!",
  "I think you should join the SHOT clan! they're the best!",
  "GG!",
  "join the SHOT clan to become a good guy",
  "I'll stop killing you if you join the SHOT clan lol",
  "join the best of the clans: SHOT!",
  "if you join the SHOT clan, you'll be allied with all the players in the clan!",
  "join the SHOT clan to become cool",
];

// Function to send a random message
function sendRandomMessage() {
  const randomIndex = Math.floor(Math.random() * messages.length);
  const message = messages[randomIndex];
 
  // Send the message to the message console
  pc.app.fire("Network:Chat", message);
}

// Function to detect keypress
function handleKeyPress(event) {
  const key = event.key;
 
  if (key === ":" || key === "/") {
    sendRandomMessage();
  }
}

// Add event listener to detect keypress
document.addEventListener("keydown", handleKeyPress);




