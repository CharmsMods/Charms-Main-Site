//==================== Author : IGLOO (AKA : ChetanIsNoob ) ======================//
//This Script let u a Better UI and gives u nice vibes while playing 
//Dont forget to read some instructions in "Overlays-Settings"
pc.app.on("Map:Loaded", () => {
    setTimeout(() => {
        pc.app.root
            .findByName("Overlay")
            .findByName("Announce").setLocalPosition(0, -530, 0);

        pc.app.root.findByName("Achievement").children[0].enabled = false;
        pc.app.root.findByName("Achievement").children[1].enabled = false;
        pc.app.root.findByName("Achievement").children[2].enabled = false;
        pc.app.root.findByName("Achievement").children[3].enabled = false;
        pc.app.root.findByName("Achievement").children[4].enabled = false;
        pc.app.root.findByName("Achievement").children[5].enabled = false;
        pc.app.root.findByName("Achievement").children[6].enabled = false;
        pc.app.root.findByName("Achievement").children[7].enabled = false;
        pc.app.root.findByName("Container").element.opacity = 0;
        pc.app.root.findByName("Task").children[0].enabled = false;
        pc.app.root.findByName("Task").children[1].enabled = false;
        pc.app.root.findByName("Task").children[2].enabled = false;
        pc.app.root.findByName("Task").children[3].enabled = false;
        pc.app.root.findByName("Task").children[4].enabled = false;
        pc.app.root.findByName("Task").children[5].enabled = false;
        pc.app.root.findByName("Task").children[6].enabled = false;
        pc.app.root.findByName("Task").enabled = false;
        pc.app.root.findByName("Overlay").findByName("Subtitle").enabled = false;

        pc.app.root
            .findByName("Overlay")
            .findByName("QuestMessage").element.opacity = 0;
        pc.app.root
            .findByName("Overlay")
            .findByName("QuestMessage")
            .findByName("Icon").element.opacity = 0;
        pc.app.root
            .findByName("Overlay")
            .findByName("QuestMessage")
            .findByName("Text").element.opacity = 0;
        pc.app.root
            .findByName("Overlay")
            .findByName("Weapons")
            .findByName("AbilityGroup")
            .findByName("AbilityBind").enabled = false;
        pc.app.root
            .findByName("Overlay")
            .findByName("TimesAndScore")
            .findByName("Background").enabled = false;
        pc.app.root
            .findByName("BarBackground").enabled = false;
        pc.app.root
            .findByName("Overlay")
            .findByName("728x90-Banner").element.opacity = 0;
        pc.app.root
            .findByName("Overlay")
            .findByName("728x90-Banner").children[0].element.opacity = 0;
        pc.app.root
            .findByName("Overlay")
            .findByName("ObjectiveHolder")
            .findByName("Objective").enabled = false;
        pc.app.root
            .findByName("Overlay")
            .findByName("ObjectiveHolder")
            .findByName("Objective").enabled = false;
        pc.app.root
            .findByName("Overlay")
            .findByName("Health").setLocalPosition(30, 640, 0);
        pc.app.root
            .findByName("Overlay")
            .findByName("Reminder").enabled = false;
        pc.app.root
            .findByName("Overlay")
            .findByName("CountBack").enabled = false;
        pc.app.root
            .findByName("Overlay").children[30].enabled = false;
        pc.app.root
            .findByName("Overlay").children[31].enabled = false;
        pc.app.root
            .findByName("Overlay").children[32].enabled = false;
        pc.app.root
            .findByName("Overlay").children[33].enabled = false;
        pc.app.root
            .findByName("Overlay").children[48].enabled = false;

        pc.app.root
            .findByName("Overlay")
            .findByName("TimesAndScore")
            .findByName("ObjectiveTime").enabled = false;
        pc.app.root
            .findByName("Overlay")
            .findByName("TimesAndScore").setLocalPosition(530, 0, 0);
        pc.app.root
            .findByName("Overlay")
            .findByName("Leaderboard").setLocalPosition(30, -660, 0);
        pc.app.root
            .findByName("Overlay")
            .findByName("Weapon").enabled = false;
        pc.app.root
            .findByName("Overlay")
            .findByName("Weapons").enabled = false;
        pc.app.root
            .findByName("Stats").setLocalPosition(590, -0.93, 0);
        pc.app.root
            .findByName("Stats").element.fontSize = 16;
        //Setting up for Mods 
        if (RedTheme == 1) {

            //thanks NEXI
            pc.app.root.findByName("Colors").script.scripts[0].meColor = [0.5, 0, 0];
            pc.app.root.findByName("Colors").script.scripts[0].health = [0.5, 0, 0];
            pc.app.root.findByName("Colors").script.scripts[0].whiteColor = [0.5, 0, 0];
            pc.app.root.findByName("Colors").script.scripts[0].greenColor = [0.5, 0, 0];
            pc.app.root.findByName("Colors").script.scripts[0].grayColor = [0.5, 0, 0];
            //Igloo one
            pc.app.root
                .findByName("Overlay")
                .findByName("Health")
                .findByName("Icon").element.color = { r: 0.5, b: 0, g: 0, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("Health").children[1].element.color = { r: 1, b: 0, g: 0, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("Health").children[2].element.color = { r: 1, b: 0, g: 0, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("Health")
                .findByName("Value").element.color = { r: 0.5, b: 0, g: 0, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("Announce")
                .findByName("Bottom").element.color = { r: 1, b: 0, g: 0, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("Announce")
                .findByName("Info").element.color = { r: 1, b: 0, g: 0, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("Text").element.color = { r: 1, b: 0, g: 0, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("Hold")
                .findByName("Bar")
                .findByName("Fill").element.color = { r: 1, b: 0, g: 0, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("DamageIndictator").element.color = { r: 1, b: 0, g: 0, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("Point")
                .findByName("Number").element.color = { r: 1, b: 0, g: 0, a: 1 };
            //thanks nexi
            pc.app.on("Overlay:Leaderboard", LeaderboardChanges());
            function LeaderboardChanges() {
                try {
                    for (
                        i = 0;
                        i <
                        pc.app.root.findByName("Overlay").findByName("Leaderboard").children
                            .length;
                        i++
                    ) {
                        pc.app.root.findByName("Overlay").findByName("Leaderboard").children[
                            i
                        ].element.color = { r: 1, b: 0, g: 0, a: 1 };
                        pc.app.root.findByName("Overlay").findByName("Leaderboard").children[
                            i
                        ].element.opacity = 0.1;
                    }
                } catch (error) { }
            }
        }
        else if (GreenTheme == 1) {
            pc.app.on("Overlay:Leaderboard", LeaderboardChanges());
            function LeaderboardChanges() {
                try {
                    for (
                        i = 0;
                        i <
                        pc.app.root.findByName("Overlay").findByName("Leaderboard").children
                            .length;
                        i++
                    ) {
                        pc.app.root.findByName("Overlay").findByName("Leaderboard").children[
                            i
                        ].element.color = { r: 0, b: 0.3, g: 1, a: 1 };
                        pc.app.root.findByName("Overlay").findByName("Leaderboard").children[
                            i
                        ].element.opacity = 0.1;
                    }
                } catch (error) { }
            }
            //thanks NEXI
            pc.app.root.findByName("Colors").script.scripts[0].meColor = [0, 1, 0];
            pc.app.root.findByName("Colors").script.scripts[0].health = [0, 1, 0];
            //Igloo ONE
            pc.app.root
                .findByName("Overlay")
                .findByName("Health")
                .findByName("Icon").element.color = { r: 0, b: 0.3, g: 1, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("Health")
                .findByName("Value").element.color = { r: 0, b: 0.7, g: 1, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("Announce")
                .findByName("Bottom").element.color = { r: 0, b: 0.3, g: 1, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("Announce")
                .findByName("Info").element.color = { r: 0, b: 0.3, g: 1, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("Text").element.color = { r: 0, b: 0.3, g: 1, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("Hold")
                .findByName("Bar")
                .findByName("Fill").element.color = { r: 0, b: 0.3, g: 1, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("DamageIndictator").element.color = { r: 0, b: 0.3, g: 1, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("Point")
                .findByName("Number").element.color = { r: 0, b: 0.3, g: 1, a: 1 };
        }
        else if (PurpleTheme == 1) {
            //thanks NEXI
            pc.app.root.findByName("Colors").script.scripts[0].meColor = [0.5, 0, 1];
            pc.app.root.findByName("Colors").script.scripts[0].health = [0.3, 0, 1];
            pc.app.root.findByName("Colors").script.scripts[0].whiteColor = [0.3, 0, 1];
            pc.app.root.findByName("Colors").script.scripts[0].greenColor = [0.3, 0, 1];
            pc.app.root.findByName("Colors").script.scripts[0].grayColor = [0.3, 0, 1];
            //Igloo ONE
            pc.app.root
                .findByName("Overlay")
                .findByName("Health")
                .findByName("Icon").element.color = { r: 0.3, b: 0.56, g: 0.23, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("Health").element.color = { r: 0.3, b: 0.56, g: 0.23, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("Health")
                .findByName("Value").element.color = { r: 0.3, b: 0.56, g: 0.23, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("Announce")
                .findByName("Bottom").element.color = { r: 0.3, b: 0.56, g: 0.23, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("Announce")
                .findByName("Info").element.color = { r: 0.3, b: 0.56, g: 0.23, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("Text").element.color = { r: 0.3, b: 0.56, g: 0.23, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("Hold")
                .findByName("Bar")
                .findByName("Fill").element.color = { r: 0.3, b: 0.56, g: 0.23, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("DamageIndictator").element.color = { r: 0.3, b: 0.56, g: 0.23, a: 1 };
            pc.app.root
                .findByName("Overlay")
                .findByName("Point")
                .findByName("Number").element.color = { r: 0.3, b: 0.56, g: 0.23, a: 1 };
            pc.app.on("Overlay:Leaderboard", LeaderboardChanges());
            function LeaderboardChanges() {
                try {
                    for (
                        i = 0;
                        i <
                        pc.app.root.findByName("Overlay").findByName("Leaderboard").children
                            .length;
                        i++
                    ) {
                        pc.app.root.findByName("Overlay").findByName("Leaderboard").children[
                            i
                        ].element.color = { r: 0.3, b: 0.56, g: 0.23, a: 1 };
                        pc.app.root.findByName("Overlay").findByName("Leaderboard").children[
                            i
                        ].element.opacity = 0.1;
                    }
                } catch (error) { }
            }
        }
    }, 2000);
});