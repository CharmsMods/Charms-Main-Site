pc.app.on("Map:Loaded", () => {
  setTimeout(() => {
	console.log("Loading custom script functions...");
    gameplayStuff();
	console.log("Custom scripts loaded!");
  }, 2000);
});

function gameplayStuff() {
  pc.app.scripts._list[0].prototype.setKeyboard = function () {
    return (
      !this.isFrozen &&
      !this.player.isDeath &&
      !pc.isFinished &&
      !this.locked &&
      "INPUT" != document.activeElement.tagName &&
      (this.jumpingTime + this.jumpLandTime < this.timestamp &&
        this.currentHeight < this.nearGround &&
        ((this.isForward = !1),
        (this.isBackward = !1),
        (this.isLeft = !1),
        (this.isRight = !1)),
      (this.app.keyboard.isPressed(pc.KEY_UP) ||
        this.app.keyboard.isPressed(pc.KEY_W) ||
        this.isMobileForward) &&
        (this.isForward = !0),
      (this.app.keyboard.isPressed(pc.KEY_DOWN) ||
        this.app.keyboard.isPressed(pc.KEY_S) ||
        this.isMobileBackward) &&
        (this.isBackward = !0),
      (this.app.keyboard.isPressed(pc.KEY_LEFT) ||
        this.app.keyboard.isPressed(pc.KEY_A) ||
        this.isMobileLeft) &&
        (this.isLeft = !0),
      (this.app.keyboard.isPressed(pc.KEY_RIGHT) ||
        this.app.keyboard.isPressed(pc.KEY_D) ||
        this.isMobileRight) &&
        (this.isRight = !0),
      this.app.keyboard.wasPressed(pc.KEY_SPACE) && this.jump(),
      this.app.keyboard.wasPressed(pc.KEY_R) && this.reload(),
      this.app.keyboard.wasPressed(pc.KEY_F) && this.triggerKeyF(),
      this.app.keyboard.wasPressed(pc.KEY_E) && this.triggerKeyE(),
      this.app.keyboard.wasPressed(pc.KEY_V) && this.player.spray(),
      this.app.keyboard.wasPressed(pc.KEY_X) &&
        ((this.leftMouse = !0), (this.isMouseReleased = !0)),
      this.app.keyboard.wasReleased(pc.KEY_X) && (this.leftMouse = !1),
      this.app.keyboard.wasPressed(pc.KEY_L) &&
        (this.app.fire("Mouse:Lock"), this.app.fire("Overlay:Pause", !1)),
      this.app.keyboard.wasPressed(pc.KEY_M),
      this.app.keyboard.wasPressed(pc.KEY_J) && this.inspect(),
      this.app.keyboard.wasPressed(pc.KEY_SHIFT) && (this.isFocusing = !0),
	  this.app.keyboard.wasPressed(pc.KEY_F2) && copyLobbyLink(),
      void (
        this.app.keyboard.wasReleased(pc.KEY_SHIFT) && (this.isFocusing = !1)
      ))
    );
  };
}

function copyLobbyLink() {
    navigator.clipboard.writeText(document.location.href);
    pc.app.fire("Chat:Message", "Client", "Link copied into clipboard!");
}