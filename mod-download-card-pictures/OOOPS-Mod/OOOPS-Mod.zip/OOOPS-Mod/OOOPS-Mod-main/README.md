<p align="center">
  <img src="https://github.com/sheeshKAAN/OOOPS-Mod/assets/132504490/4e136499-ecd6-4918-be4c-ef3f46c77255)https://github.com/sheeshKAAN/OOOPS-Mod/assets/132504490/4e136499-ecd6-4918-be4c-ef3f46c77255" width="100" height="60" alt="NexiClient">
</p>

# OOOPS Mod
OOOPS Mod was created by OOOPS and Nexi2k in 2020. However, after 2 years, the mode was not working due to updates and innovations. We have updated the OOOPS Mode in accordance with the new version of the game and made it available on the Venge Client, and we will continue to update it in other versions. *By downloading OOOPS Mod you promise to abide by the following rules:*

1- You should use the client without the intention of stealing the code or modifying the code in the client without permission from the developers.

2- Please refrain from spreading the client's GitHub link, and instead distribute the Discord link. 

3- The game's asset files belong to OOOPS Mod and Special Offers. Sharing of assets in any way without approval is prohibited.

⚠️- **DO NOT open JSON files for any reason**, leave them as they are. Opening and modifying them is unauthorized _(not allowed)_ and the developers will know that you have opened and modified them, so do not attempt this or you may receive a _**PERMANET BAN**_.
  
## Installation  <a name="installation"></a>

- Download the latest release of the mod (The mod on the main side is always the most up-to-date)
- Unzip the downloaded folder and copy the subfolder titled "Venge Client"
- Navigate to your PC's Documents folder and ensure that there isn't already a folder named Venge Client in it. If there is one, delete it prior to attempting the next step 
- Paste the copied Venge Client folder here
- Launch Venge Client. The mod has been applied successfully

# [Client](https://social.venge.io/client) Shortcuts
F1 - Leaves the game back to the main menu

F2 - Opens a dialog where you can join your friends via an invite link

F3 - Copies the Link of your current game

F9 - Opens the developer tool

F7 - Userscrpit Manager

F10 - Opens Settings Menu to configure FPS cap, Discord RPC, and D3D11OND12.

F11 - Toggles full screen mode

# Contact
To report issues or enquire about somethin; [OOOPS Mod dicord server](https://youtube.com/@OOOPSio?si=KjjgGN1gNQo6A8sd)

If you want to send us suggestions or bugs about the mod:
🐞[Report Bugs](https://github.com/sheeshKAAN/OOOPS-mod/issues/3) - 💭[Suggestions](https://github.com/sheeshKAAN/OOOPS-mod/issues/4)
#  Credits
**Creative:**
**[OOOPS](https://youtube.com/@OOOPSio?si=KjjgGN1gNQo6A8sd)** and **[Nexi2k](https://github.com/NeXiDE)** 


**Developed in collaboration by:** 
**[KAAN](https://github.com/sheeshKAAN)** and **[Just Joe](https://github.com/JustxJoe)**

**Contributors:**
**[Captain Cool](https://github.com/Capta1nCool)** and **[AbyssYT](https://github.com/AbyssYT6)**
 

## Was used in this project:
![Visual Studio Code](https://img.shields.io/badge/Visual%20Studio%20Code-0078d7.svg?style=for-the-badge&logo=visual-studio-code&logoColor=white) ![JavaScript](https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=javascript&logoColor=%23F7DF1E) ![NodeJS](https://img.shields.io/badge/node.js-6DA55F?style=for-the-badge&logo=node.js&logoColor=white)  <img src="https://upload.wikimedia.org/wikipedia/commons/8/8b/Picsart_%28software_company%29_logo.svg" width="100" height="50">   <img alt="Blender" src="https://img.shields.io/badge/Blender-F5792A?style=for-the-badge&logo=blender&logoColor=white">

# License

This project is licensed under the Creative Commons Attribution License (CC-BY) - see the [LICENSE](https://github.com/sheeshKAAN/OOOPS-Mod?tab=MIT-1-ov-file#readme) file for details.
