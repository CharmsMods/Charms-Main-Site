app.settingsTabs.push({ name: 'Venge Script', icon: 'fa-bolt', tab: 'Client' });
app.customSettings.push({ name: 'Start Message', type: 'message', value: 'Official Venge Scripts!', tab: 'Client' });
app.customSettings.push({ name: 'Disable Light', type: 'checkbox', value: true, tab: 'Client' });
app.customSettings.push({ name: 'HideWeaponOnAds', type: 'checkbox', value: true, tab: 'Client' });
app.customSettings.push({ name: 'Start Message For Model Script', type: 'message', value: 'Weapon Model Changes', tab: 'Client' });
app.customSettings.push({ name: 'modelPosX', type: 'slider', value: 0, min: -100, max: 100, tab: 'Client' });
app.customSettings.push({ name: 'modelPosY', type: 'slider', value: 0, min: -100, max: 100, tab: 'Client' });
app.customSettings.push({ name: 'modelPosZ', type: 'slider', value: 0, min: -100, max: 100, tab: 'Client' });

pc.app.on("Map:Loaded", () => {
	if(!app.getStorage('Disable Light')) return pc.app.root.findByName("MapHolder").children[0].light.color = {r: 1, g: 1, b: 1, a: 1};
    try {
        pc.app.root.findByName("MapHolder").children[0].light.color = {r: 0, g: 0, b: 0, a: 1};
    } catch (error) {
        console.log(error);
    }
    try {
        let demultiplier = 0.01;
        window.point = pc.app.root.findByName("WeaponPoint");
        if(!window.pointlocalPosition) window.pointlocalPosition = window.point.localPosition;
        window.point.localPosition = { x: window.point.localPosition.x + (app.getStorage('modelPosX')*demultiplier), y: window.point.localPosition.y + (app.getStorage('modelPosY')*demultiplier), z: window.point.localPosition.z + (app.getStorage('modelPosZ')*demultiplier) };
        
        window.center = pc.app.root.findByName("WeaponCenter");
        if(!window.centerlocalScale) window.centerlocalScale = window.center.localScale;
        window.point.localScale = { x: window.center.localScale.x + (app.getStorage('modelScaleX')*demultiplier), y: window.center.localScale.y + (app.getStorage('modelScaleY')*demultiplier), z: window.center.localScale.z + (app.getStorage('modelScaleZ')*demultiplier) };
    } catch (e) {
    }
});

pc.app.on('Player:Focused', function(state) {
    if(!app.getStorage('HideWeaponOnAds')) return;
    if(state) {
        pc.app.scene.layers.getLayerByName('NonFOV').enabled = false;
        let crosshair = pc.app.root.findByName('Crosshair');
        crosshair.enabled = true;
    } else {
        pc.app.scene.layers.getLayerByName('NonFOV').enabled = true;
    }
});

pc.app.on('Client:CustomSettingsChange', function(setting) {
    if(setting.name == 'Disable Light') {
        if(setting.value) {
            try {
                pc.app.root.findByName("MapHolder").children[0].light.color = {r: 0, g: 0, b: 0, a: 1};
                app.alert('Disabled Light');
            } catch (error) {
                console.log(error);
            }
        } else {
            pc.app.root.findByName("MapHolder").children[0].light.color = {r: 1, g: 1, b: 1, a: 1};
            app.alert('Enabled Light', true);
        }
    }

    if(setting.name == 'HideWeaponOnAds') {
        if(setting.value) {
            app.alert('Weapon disabled on ADS');
        } else {
            app.alert('Weapon enabled on ADS', true);
        }
    }

    if(setting.name == 'modelPosX') {
        try {
            window.point.localPosition.x = window.pointlocalPosition.x + (parseInt(setting.value)*0.01);
        } catch (e) {
        }
    }
    if(setting.name == 'modelPosY') {
        try {
            window.point.localPosition.y = window.pointlocalPosition.y + (parseInt(setting.value)*0.01);
        } catch (e) {
        }
    }
    if(setting.name == 'modelPosZ') {
        try {
            window.point.localPosition.z = window.pointlocalPosition.z + (parseInt(setting.value)*0.01);
        } catch (e) {
        }
    }
    if(setting.name == 'modelScaleX') {
        try {
            window.center.localScale.x = window.centerlocalScale.x + (parseInt(setting.value)*0.01);
        } catch (e) {
        }
    }
    if(setting.name == 'modelScaleY') {
        try {
            window.center.localScale.y = window.centerlocalScale.y + (parseInt(setting.value)*0.01);
        } catch (e) {
        }
    }
    if(setting.name == 'modelScaleZ') {
        try {
            window.center.localScale.z = window.centerlocalScale.z + (parseInt(setting.value)*0.01);
        } catch (e) {
        }
    }
});